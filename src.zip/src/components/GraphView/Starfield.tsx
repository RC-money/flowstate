import React, { useEffect, useRef } from "react";

interface StarfieldProps {
  enabled: boolean;
  zoom: number;
}

type Star = {
  x: number;
  y: number;
  r: number;
  alpha: number;
  speed: number;
};

const Starfield: React.FC<StarfieldProps> = ({ enabled, zoom }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const frameRef = useRef<number>();
  const roRef = useRef<ResizeObserver | null>(null);
  const starsRef = useRef<Star[]>([]);
  const sizeRef = useRef<{ w: number; h: number }>({ w: 0, h: 0 });

  const initStars = (w: number, h: number) => {
    const base = Math.min(300, Math.max(120, Math.round((w * h) / 12000)));
    starsRef.current = Array.from({ length: base }, () => ({
      x: Math.random() * w,
      y: Math.random() * h,
      r: Math.random() * 1.2 + 0.3,
      alpha: Math.random() * 0.6 + 0.4,
      speed: (Math.random() - 0.5) * 0.25,
    }));
  };

  const resizeCanvas = (canvas: HTMLCanvasElement) => {
    const parent = canvas.parentElement;
    if (!parent) return;
    const dpr = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
    const rect = parent.getBoundingClientRect();
    const w = Math.max(1, Math.floor(rect.width));
    const h = Math.max(1, Math.floor(rect.height));
    sizeRef.current = { w, h };
    canvas.style.width = `${w}px`;
    canvas.style.height = `${h}px`;
    canvas.width = Math.floor(w * dpr);
    canvas.height = Math.floor(h * dpr);
    const ctx = canvas.getContext("2d");
    if (ctx) ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    initStars(w, h);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    resizeCanvas(canvas);

    if (!roRef.current) {
      roRef.current = new ResizeObserver(() => resizeCanvas(canvas));
    }
    const parent = canvas.parentElement;
    if (parent) roRef.current.observe(parent);

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const draw = () => {
      if (!enabled) return;
      const { w, h } = sizeRef.current;
      ctx.clearRect(0, 0, w, h);
      const parallax = (1 / Math.max(0.5, zoom)) * 0.6;
      for (const star of starsRef.current) {
        star.x += star.speed * parallax;
        if (star.x < 0) star.x = w;
        if (star.x > w) star.x = 0;
        ctx.beginPath();
        ctx.globalAlpha = star.alpha;
        ctx.fillStyle = "#ffffff";
        ctx.arc(star.x, star.y, star.r, 0, Math.PI * 2);
        ctx.fill();
      }
      frameRef.current = window.requestAnimationFrame(draw);
    };

    frameRef.current = window.requestAnimationFrame(draw);

    return () => {
      if (frameRef.current) cancelAnimationFrame(frameRef.current);
      if (roRef.current && parent) roRef.current.unobserve(parent);
    };
  }, [enabled, zoom]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 -z-10 pointer-events-none rounded-2xl"
      style={{ transition: "opacity 0.35s ease", opacity: enabled ? 1 : 0 }}
      aria-hidden
    />
  );
};

export default Starfield;
